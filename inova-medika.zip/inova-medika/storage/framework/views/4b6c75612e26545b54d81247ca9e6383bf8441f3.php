
<?php $__env->startSection('title'); ?>
Details Page
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div id="layoutSidenav">
    <div id="layoutSidenav_nav">
        <?php echo $__env->make('includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid">
                <h3 class="mt-4">Input Obat</h3>
                <div class="container" style="padding-top:50px ;">
                    <div class="row justify-content-center">
                        <div class="col">
                            <div class="card shadow-sm">
                                <div class="card-body">
                                    <h4 class="form-title">Form Input Obat</h4>
                                    <form action="#" method="POST" enctype="multipart/form-data">
                                        <div class="row mt-3">
                                            <div class="col-5 col-sm-12 col-md-12 col-lg-5">
                                                <label for="nama_obat">Nama Obat</label>
                                                <input type="form-control" name="nama_obat" id="nama_obat" class="form-control">
                                            </div>
                                            <div class="col mt-4">
                                                <select class="form-select" name="satuan_obat" id="satuan_obat">
                                                    <option selected>Pilih Satuan</option>
                                                    <option value="1">Tablet</option>
                                                    <option value="2">Botol</option>
                                                    <option value="3">Kaplet</option>
                                                </select>
                                            </div>
                                            <div class="col">
                                                <label for="jumlah_obat">Jumlah Obat</label>
                                                <input type="form-control" name="jumlah_obat" id="jumlah_obat" class="form-control">
                                            </div>
                                            <div class="col">
                                                <label for="harga_obat">Harga Obat</label>
                                                <input type="form-control" name="harga_obat" id="harga_obat" class="form-control">
                                            </div>
                                        </div>
                                        <div class="form-group text-right mt-4">
                                            <a href="#" class="btn btn-white mr-2" type="reset">Cancel</a>
                                            <button type="button" class="btn btn-primary">Submit</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>
<?php $__env->stopSection(); ?>
</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web development\Aplikasi Klinik\inova-medika\resources\views/tambah_obat.blade.php ENDPATH**/ ?>