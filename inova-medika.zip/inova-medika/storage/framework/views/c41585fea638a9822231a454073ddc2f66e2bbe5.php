

<?php $__env->startSection('title'); ?>
Tindakan Dan Obat
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <body class="sb-nav-fixed">
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <?php echo $__env->make('includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid">
                        <h3 class="my-4">Data Pasien Terdaftar</h3>
                        <div class="container-fluid px-4">
                            <div class="card mb-4">
                                <div class="card-body">
                                    <table id="datatablesSimple">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>NIK</th>
                                                <th>Nama Pasien</th>
                                                <th>Pegawai</th>
                                                <th>Wilayah</th>
                                                <th>Status Tindakan</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <th> <?php echo e($item->tdo_id); ?> </th>
                                                <th> <?php echo e($item->NIK); ?> </th>
                                                <th> <?php echo e($item->nama_pasien); ?> </th>
                                                <td> <?php echo e($item->user_tabel->name); ?> </td>
                                                <td> <?php echo e($item->masterwilayah_tabel->nama_wilayah); ?> </td>
                                                <td> <?php echo e($item->status_tindakan); ?> </td>
                                                <td>
                                                    <a href=" <?php echo e(route('menu_tindakan_dan_obat.edit',$item->tdo_id)); ?> " class="btn btn-warning">
                                                        <i class="fa fa-pencil-alt"></i>
                                                    </a>
                                                    <form action=" <?php echo e(route('menu_tindakan_dan_obat.destroy',$item->tdo_id)); ?> " method="POST" class="d-inline">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('delete'); ?>
                                                        <button class="btn btn-danger" type="submit">
                                                            <i class="fa fa-trash"></i>
                                                        </button>
                                                    </form>
                                                </td>
                
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                
                                            <?php endif; ?>
                                           
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
        </div>
    </body>
    <?php $__env->stopSection(); ?>
</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web development\Aplikasi Klinik\inova-medika\resources\views/pages/tindakan_dan_obat/index.blade.php ENDPATH**/ ?>