

<?php $__env->startSection('title'); ?>
Menu Pasien
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <body class="sb-nav-fixed">
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <?php echo $__env->make('includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid">
                        <h3 class="my-4">Data Pasien</h3>
                        <div class="container-fluid px-4">
                            <div class="card mb-4">
                                <div class="card-body">
                                    <div class="text-end mb-4">
                                        <a href=" <?php echo e(route('menu_pasien.create')); ?> " class="btn btn-success">Tambah Pasien</a>
                                    </div>
                                    <table id="datatablesSimple">
                                        <thead>
                                            <tr>
                                                <th>Id Pasien</th>
                                                <th>Nama Pasien</th>
                                                <th>NIK</th>
                                                <th>Pegawai</th>
                                                <th>Wilayah</th>
                                          
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__empty_1 = true; $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <tr>
                                                    <td> <?php echo e($item->pasien_id); ?> </td>
                                                    <td> <?php echo e($item->nama_pasien); ?> </td>
                                                    <td> <?php echo e($item->NIK); ?> </td>
                                                    <td> <?php echo e($item->user_tabel->name); ?> </td>
                                                    <td> <?php echo e($item->masterwilayah_tabel->nama_wilayah); ?> </td>
                                                    
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; Your Website 2022</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
    </body>
    <?php $__env->stopSection(); ?>
</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web development\Aplikasi Klinik\inova-medika\resources\views/pages/menu_pasien/index.blade.php ENDPATH**/ ?>