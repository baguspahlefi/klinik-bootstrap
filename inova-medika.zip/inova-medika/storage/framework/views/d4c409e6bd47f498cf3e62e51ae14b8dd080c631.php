  <!-- Styles -->
  <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
  <link href=" <?php echo e(url('styles/css/styles-bootstrap.css')); ?> " rel="stylesheet" />
  <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script><?php /**PATH D:\web development\Aplikasi Klinik\inova-medika\resources\views/includes/style.blade.php ENDPATH**/ ?>