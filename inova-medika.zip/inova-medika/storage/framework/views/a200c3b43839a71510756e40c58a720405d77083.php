
<?php $__env->startSection('title'); ?>
Tindakan Dan Obat Pasien
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div id="layoutSidenav">
    <div id="layoutSidenav_nav">
        <?php echo $__env->make('includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid">
                <h3 class="mt-4">Tindakan Dan Obat Pasien</h3>
                <div class="container" style="padding-top:50px ;">
                    <div class="row justify-content-center">
                        <div class="col">
                            <div class="card shadow-sm">
                                <div class="card-body">
                                    <h4 class="form-title">Form Tindakan Dan Obat</h4>
                                    <form action="<?php echo e(route('menu_tindakan_dan_obat.update',$item->tdo_id)); ?>" class="row g-3 needs-validation" novalidate method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('put'); ?>
                                        <div class="col-md-4">
                                            <label for="validationCustom02" class="form-label">No KTP</label>
                                            <input readonly="readonly" type="text" class="form-control" id="exampleFormControlInput1" name="NIK" value="<?php echo e($item->NIK); ?>" >
                                        </div>
                                        <div class="col-md-4">
                                            <label for="validationCustom02" class="form-label">Nama Pasien</label>
                                            <input type="text" class="form-control" id="exampleFormControlInput1" name="nama_pasien" value="<?php echo e($item->nama_pasien); ?>" readonly="readonly">
                                        </div>
                                        <div class="col-md-4">
                                            <label for="validationCustom02" class="form-label">No HP</label>
                                            <input type="text" class="form-control" id="exampleFormControlInput1" name="no_phone" value="<?php echo e($item->no_phone); ?>" readonly="readonly">
                                        </div>
                                        <div class="col-md-4">
                                            <label for="validationCustom02" class="form-label">Tanggal Lahir</label>
                                            <input type="text" class="form-control" id="exampleFormControlInput1" name="tanggal_lahir" value="<?php echo e($item->tanggal_lahir); ?>" readonly="readonly">
                                        </div>
                                        <div class="col-md-4">
                                            <label for="validationCustom02" class="form-label">Jenis Kelamin</label>
                                            <input type="text" class="form-control" id="exampleFormControlInput1" name="jenis_kelamin" value="<?php echo e($item->jenis_kelamin); ?>" readonly="readonly">
                                        </div>
                                        <div class="col-md-4">
                                            <label for="validationCustom02" class="form-label">Keluhan</label>
                                            <input type="text" class="form-control" id="exampleFormControlInput1" name="keluhan" value="<?php echo e($item->keluhan); ?>" readonly="readonly">
                                        </div>
                                        <div class="col-md-4">
                                            <label for="validationCustom02" class="form-label">Pegawai</label>
                                            <select name="pegawai_id" required class="form-select" readonly="readonly">
                                                <option required value=" <?php echo e($item->pegawai_id); ?> "> <?php echo e($item->user_tabel->name); ?> </option>
                                                
                                                    <option value="<?php echo e($item->pegawai_id); ?>">
                                                        <?php echo e($item->wilayah_); ?>

                                                    </option>
                                               
                                            </select>
                                        </div>
                                        <div class="col-md-4">
                                            <label for="validationCustom02" class="form-label">Wilayah</label>
                                            <select name="wilayah_id" required class="form-select" readonly="readonly">
                                                <option required value=" <?php echo e($item->wilayah_id); ?> "> <?php echo e($item->masterwilayah_tabel->nama_wilayah); ?> </option>    
                                            </select>
                                        </div>
                                        <div class="col-md-4">
                                            <label for="validationCustom02" class="form-label">Jenis Tindakan</label>
                                            <select name="tindakan_id" required class="form-select">
                                                <option required value="tindakan_id">Pilih Jenis Tindakan</option>
                                                <?php $__currentLoopData = $tindakan_item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->tindakan_id); ?>">
                                                        <?php echo e($item->nama_tindakan); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="col-md-4">
                                            <label for="validationCustom02" class="form-label">Jenis Obat</label>
                                            <select name="obat_id" required class="form-select">
                                                <option required value="obat_id">Pilih Jenis Obat</option>
                                                <?php $__currentLoopData = $obat_item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->obat_id); ?>">
                                                        <?php echo e($item->nama_obat); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="col-md-4">
                                            <label for="validationCustom02" class="form-label">Status Tindakan</label>
                                            <select class="form-select" name="status_tindakan" id="satuan">
                                                <option selected> <?php echo e($item->status_tindakan); ?> </option>
                                                <option value="sudah">Sudah</option>
                                                <option value="belum">Belum</option>

                                            </select>
                                        </div>
                                        
                                        <div class="col-12">
                                            <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="" id="invalidCheck" required>
                                            <label class="form-check-label" for="invalidCheck">
                                                Agree to terms and conditions
                                            </label>
                                            <div class="invalid-feedback">
                                                You must agree before submitting.
                                            </div>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <button class="btn btn-primary" type="submit">Submit form</button>
                                        </div>
                                        </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>
<?php $__env->stopSection(); ?>
</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web development\Aplikasi Klinik\inova-medika\resources\views/pages/tindakan_dan_obat/tindakan.blade.php ENDPATH**/ ?>