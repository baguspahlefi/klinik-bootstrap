<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\web development\Aplikasi Klinik\inova-medika\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>