
<?php $__env->startSection('title'); ?>
Tambah Tindakan
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div id="layoutSidenav">
    <div id="layoutSidenav_nav">
        <?php echo $__env->make('includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid">
                <h3 class="mt-4">Tambah Tindakan</h3>
                <div class="container" style="padding-top:50px ;">
                    <div class="row justify-content-center">
                        <div class="col">
                            <div class="card shadow-sm">
                                <div class="card-body">
                                    <h4 class="form-title">Form Input Tindakan</h4>
                                    <form action="<?php echo e(route('master_tindakan.store')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <div class="col-md-4">
                                            <label for="validationCustom01" class="form-label">Nama Tindakan</label>
                                            <input type="text" name="nama_tindakan" class="form-control" id="validationCustom01" value="" required>
                                            <div class="valid-feedback">
                                            Looks good!
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <label for="validationCustom02" class="form-label">Tarif</label>
                                            <input type="text" name="tarif" class="form-control" id="validationCustom02" value="" required>
                                            <div class="valid-feedback">
                                            Looks good!
                                            </div>
                                        </div>
                                        <div class="col-12 py-4">
                                            <button class="btn btn-primary" type="submit">Submit form</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>
<?php $__env->stopSection(); ?>
</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web development\Aplikasi Klinik\inova-medika\resources\views/pages/master_tindakan/create.blade.php ENDPATH**/ ?>