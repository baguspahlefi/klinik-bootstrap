
<?php $__env->startSection('title'); ?>
Details Page
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <?php echo $__env->make('includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid">
                        <h3 class="mt-4">Input Data Master Wilayah</h3>
                        <div class="container" style="padding-top:70px ;">
                            <div class="row justify-content-center">
                                <div class="col-8">
                                    <div class="card shadow-sm">
                                        <div class="card-body">
                                            <h4 class="form-title">Form input wilayah</h4>
                                            <form action="<?php echo e(route('master_wilayah.store')); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <div class="form-group">
                                                    <input type="text" name="nama_wilayah" id="nama_wilayah" class="form-control">
                                                </div>
                                                <div class="form-group text-right mt-4">
                                                    <a href="#" class="btn btn-white mr-2" type="reset">Cancel</a>
                                                    <button type="submit" class="btn btn-primary">Submit</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
        </div>
    </body>
    <?php $__env->stopSection(); ?>
</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web development\Aplikasi Klinik\inova-medika\resources\views/pages/master_wilayah/create.blade.php ENDPATH**/ ?>