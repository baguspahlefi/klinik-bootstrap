<?php echo e($slot); ?>

<?php /**PATH D:\web development\Aplikasi Klinik\inova-medika\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>